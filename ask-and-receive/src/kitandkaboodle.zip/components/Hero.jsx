import { useTheme } from "../providers/ThemeContext"

export default function Hero({ status, onClearSavedData }) {
  const activeTheme = useTheme()

  return (
    <section className="mx-auto max-w-6xl px-6 pt-16 pb-12">
      <div className="max-w-4xl">
        <h1 className={`text-4xl md:text-4xl font-semibold tracking-tight leading-tight ${activeTheme.primaryText}`}>
          You need something. I have something. Let's get together.
        </h1>

        <p className={`mt-4 max-w-2xl leading-7 ${activeTheme.secondaryText}`}>
          Honest asks. Real generosity. No drama. Just moments.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <a
            href="#post-ask"
            className={`rounded-2xl bg-gradient-to-r ${activeTheme.solidButton} ${activeTheme.buttonText} px-5 py-3 font-medium transition`}
          >
            Add an Ask
          </a>

          <a
            href="#asks"
            className={`rounded-2xl px-5 py-3 transition ${activeTheme.surfaceButton}`}
          >
            Browse Asks
          </a>

        </div>

        {status ? (
          <div
            className={`mt-6 rounded-2xl border px-4 py-3 text-sm ${activeTheme.accentBorder} ${activeTheme.accentBg} ${activeTheme.accentText}`}
          >
            {status}
          </div>
        ) : null}
      </div>
    </section>
  )
}