import OfferMessages from "./OfferMessages"

export default function RelatedOfferCard({
  offer,
  hasGratitudeStory,
  onProfileClick,
  onOpenGratitude,
  onAcceptOffer,
  onDeclineOffer,
  onFulfillOffer,
  activeTheme,
  messages,
  unreadCount,
  isMessagesExpanded,
  onToggleMessages,
  onMarkMessagesAsRead,
  handleMarkMessagesAsRead,
  currentUserId,
  messageValue,
  onMessageChange,
  onSendMessage,
}) {
  return (
    <div className={`rounded-2xl border ${activeTheme.inputBorder} ${activeTheme.sectionBg} p-4`}>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <div>
            <div className={`text-sm ${activeTheme.subtleText}`}>Helper</div>
            <div
              onClick={() => onProfileClick(offer.user_id, offer.helper_name)}
              className={`flex items-center gap-2 text-sm ${activeTheme.mutedText} cursor-pointer hover:underline`}
            >
              <span>{offer.helper_name || "Someone offered help"}</span>
              {unreadCount > 0 && (
                <span className="ml-2 rounded-full bg-red-600 px-2 py-0.5 text-xs font-bold text-white">
                  {unreadCount}
                </span>
              )}
            </div>
          </div>

          <div>
            <div className={`text-sm ${activeTheme.subtleText}`}>Status</div>
            <div className={`text-sm ${activeTheme.secondaryText}`}>
              {offer.status || "pending"}
            </div>
          </div>

          {offer.status === "fulfilled" && !hasGratitudeStory && (
            <div className="flex gap-2">
              <button
                onClick={() => onOpenGratitude(offer.ask_id)}
                className={`rounded-xl bg-gradient-to-r ${activeTheme.button} px-3 py-1 text-sm font-semibold ${activeTheme.buttonText} transition`}
              >
                Share Gratitude
              </button>
            </div>
          )}

          {offer.status === "pending" && (
            <div className="flex gap-2">
              <button
                onClick={() => onAcceptOffer(offer.id, offer.ask_id)}
                className={`rounded-xl ${activeTheme.successButton} px-3 py-1 text-sm font-semibold ${activeTheme.successText} transition`}
              >
                Accept
              </button>

              <button
                onClick={() => onDeclineOffer(offer.id)}
                className={`rounded-xl bg-gradient-to-r ${activeTheme.dangerButton} px-3 py-1 text-sm font-semibold ${activeTheme.buttonText} transition`}
              >
                Decline
              </button>
            </div>
          )}

          {offer.status === "accepted" && (
            <div className="flex gap-2">
              <button
                onClick={() => onFulfillOffer(offer.id)}
                className={`rounded-xl bg-gradient-to-r ${activeTheme.button} px-3 py-1 text-sm font-semibold ${activeTheme.buttonText} transition`}
              >
                Mark Fulfilled
              </button>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <div className={`text-sm ${activeTheme.subtleText}`}>Their Offer</div>
            <div className={`mt-2 text-sm ${activeTheme.secondaryText}`}>
              {offer.helper_message}
            </div>
          </div>

          <OfferMessages
            offerId={offer.id}
            unreadCount={unreadCount}
            isExpanded={isMessagesExpanded}
            onToggle={onToggleMessages}
            messages={messages}
            currentUserId={currentUserId}
            activeTheme={activeTheme}
            messageValue={messageValue}
            onMessageChange={onMessageChange}
            onSendMessage={onSendMessage}
            onMarkMessagesAsRead={handleMarkMessagesAsRead}
            onMarkMessagesAsRead={onMarkMessagesAsRead}
          />
        </div>
      </div>
    </div>
  )
}
